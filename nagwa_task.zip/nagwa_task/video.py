# import pandas 
import os
import xml.dom.minidom
from retriever import getElementsByTagName
from retriever import getElementAttribute
import csv


for file in os.listdir('VideoTranscripts') :
    csvFile = open('output/videos/'+file+".csv" , "w")
    writer = csv.writer(csvFile)

    xml_file = xml.dom.minidom.parse("VideoTranscripts/"+file) 
    questions = xml_file.getElementsByTagName('question');
    
    # print((questions))
    for question in questions : 
        
      questionId = getElementAttribute(question , "id")
      print("question : " + questionId)
      writer.writerow(["question : " , questionId])
    
      mediaIdentifier = getElementAttribute(question , "media_identifier")        
      print("mediaIdentifier : " + mediaIdentifier)
      writer.writerow(["mediaIdentifier : " , mediaIdentifier])
        
        
      questionTitle = getElementsByTagName(question ,"question_title")
      print("Title : " + questionTitle)
      writer.writerow(["Title : " , questionTitle.encode('utf-8')])
        
      answerStepes = question.getElementsByTagName('s')
    
      firstTime = getElementAttribute(answerStepes[0] , "start_time")
      endTime = getElementAttribute(answerStepes[len(answerStepes) - 1] , "end_time")
    
      print("start_time : "+ firstTime )
      writer.writerow(["start_time : " ,firstTime])
      print("end_time : "+ endTime )
      writer.writerow(["end_time : ",endTime] )
     
    csvFile.close()

 
    
